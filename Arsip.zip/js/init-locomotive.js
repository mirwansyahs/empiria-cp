// Scroll animation
(function () {
    var scroll = new LocomotiveScroll({
        el: document.querySelector('[data-scroll-container]'),
        smooth: true
    });
    // var scrollSimpleA = new LocomotiveScroll({
    //     el: document.querySelector('.scroll-simple-a'),
    //     smooth: true,
    //     direction: 'horizontal'
    // });
})();